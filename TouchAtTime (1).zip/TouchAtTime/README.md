# TouchAtTime

An Android app that taps the screen at a chosen (X, Y) point at a chosen
time (HH:MM:SS, plus hundredths of a second).

## How it works
- `TapAccessibilityService` is an Android AccessibilityService, which is
  the only public API that lets an app inject a synthetic touch anywhere
  on screen (even into other apps). You must enable it manually once,
  in Settings, the same way you'd enable any accessibility tool.
- `MainActivity` lets you enter the point and the time, or tap
  "Pick point by touching overlay" to tap the exact spot instead of
  guessing pixel coordinates.
- When you hit "Schedule Tap", the app computes the target time today
  (or tomorrow, if that time already passed), wakes up ~60ms early via
  a Handler, then busy-waits on a dedicated thread for the last stretch
  and fires the tap as close to the exact millisecond as it can.

## About the 1/100s precision
Android does not guarantee sub-10ms scheduling accuracy anywhere in its
stack — not in `Handler`, not in `AlarmManager`, and not in the
accessibility gesture-dispatch pipeline itself, which is asynchronous
and can add its own few-millisecond delay before the tap actually lands
on screen. This app gets as close as is realistically possible (the
busy-wait removes most Handler jitter), but expect real-world accuracy
in the ballpark of ±5-20ms rather than an exact 10ms guarantee,
especially on lower-end devices, if the screen is off, or under
battery-saver restrictions.

## Building it
This project wasn't compiled here — I don't have the Android SDK /
Gradle toolchain or network access in this environment. Two ways to
get an installable `.apk`:

### Option A: GitHub Actions (no local install needed)
1. Create a new **public or private** GitHub repo and push this whole
   `TouchAtTime` folder to it (including the `.github` folder).
2. GitHub will automatically run the included workflow
   (`.github/workflows/build.yml`) on push — or trigger it manually
   from the repo's **Actions** tab ("Build APK" > "Run workflow").
3. When it finishes (a couple of minutes), open the finished run and
   download the **TouchAtTime-debug-apk** artifact — that's a zip
   containing `app-debug.apk`.
4. Transfer the APK to your phone (e.g. via a cloud drive, USB, or
   emailing it to yourself), then tap it to install. You'll need to
   allow "install from unknown sources" the first time.

### Option B: Android Studio
1. Open the `TouchAtTime` folder in Android Studio (Giraffe or newer).
2. Let it sync Gradle (needs internet, first time).
3. Run on a device or emulator running Android 8.0 (API 26) or later,
   or use Build > Build Bundle(s)/APK(s) > Build APK(s) to get a file.
4. On first run, tap "1. Enable Accessibility Service" and turn
   TouchAtTime on in the system list.
5. Set X/Y (or use the point picker), set the time, tap
   "2. Schedule Tap".

## Known limitations
- If the screen is off or the device is in deep sleep (Doze), the tap
  may be delayed or dropped — a screen tap needs the display on.
- Only one tap can be scheduled at a time in this version; scheduling a
  new one cancels the old one.
- Google Play has restrictions on accessibility-service apps used for
  automation; this is intended for personal/local use (e.g. via
  Android Studio or sideloading), not Play Store distribution as-is.
