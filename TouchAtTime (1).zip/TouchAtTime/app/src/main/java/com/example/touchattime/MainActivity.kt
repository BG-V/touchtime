package com.example.touchattime

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var editX: EditText
    private lateinit var editY: EditText
    private lateinit var editHH: EditText
    private lateinit var editMM: EditText
    private lateinit var editSS: EditText
    private lateinit var editCS: EditText
    private lateinit var textStatus: TextView

    private val mainHandler = Handler(Looper.getMainLooper())
    private var wakeRunnable: Runnable? = null
    private var spinThread: Thread? = null

    // How long before the target time we wake the main handler and hand
    // off to a dedicated spin-wait thread. Handler/AlarmManager timing on
    // Android is only accurate to roughly +/-15-50ms, so we wake early and
    // busy-wait the last stretch on its own thread for tighter precision.
    private val LEAD_MS = 60L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editX = findViewById(R.id.editX)
        editY = findViewById(R.id.editY)
        editHH = findViewById(R.id.editHH)
        editMM = findViewById(R.id.editMM)
        editSS = findViewById(R.id.editSS)
        editCS = findViewById(R.id.editCS)
        textStatus = findViewById(R.id.textStatus)

        findViewById<Button>(R.id.btnPickPoint).setOnClickListener {
            startActivityForResult(Intent(this, PickPointActivity::class.java), 100)
        }

        findViewById<Button>(R.id.btnEnableService).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            Toast.makeText(this, "Find TouchAtTime in the list and turn it on", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.btnSchedule).setOnClickListener { onScheduleClicked() }

        findViewById<Button>(R.id.btnCancel).setOnClickListener { cancelScheduled() }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && data != null) {
            editX.setText(data.getIntExtra("x", 0).toString())
            editY.setText(data.getIntExtra("y", 0).toString())
        }
    }

    private fun onScheduleClicked() {
        if (TapAccessibilityService.instance == null) {
            Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_LONG).show()
            return
        }

        val x = editX.text.toString().toFloatOrNull()
        val y = editY.text.toString().toFloatOrNull()
        val hh = editHH.text.toString().toIntOrNull()
        val mm = editMM.text.toString().toIntOrNull()
        val ss = editSS.text.toString().toIntOrNull() ?: 0
        val cs = editCS.text.toString().toIntOrNull() ?: 0

        if (x == null || y == null || hh == null || mm == null) {
            Toast.makeText(this, "Fill in X, Y, HH and MM", Toast.LENGTH_SHORT).show()
            return
        }
        if (hh !in 0..23 || mm !in 0..59 || ss !in 0..59 || cs !in 0..99) {
            Toast.makeText(this, "Time values out of range", Toast.LENGTH_SHORT).show()
            return
        }

        cancelScheduled()

        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hh)
            set(Calendar.MINUTE, mm)
            set(Calendar.SECOND, ss)
            set(Calendar.MILLISECOND, cs * 10)
        }
        if (target.timeInMillis <= System.currentTimeMillis()) {
            target.add(Calendar.DAY_OF_MONTH, 1)
        }
        val targetMillis = target.timeInMillis
        val delay = targetMillis - System.currentTimeMillis()

        textStatus.text = "Status: scheduled for ${"%02d:%02d:%02d.%02d".format(hh, mm, ss, cs)} " +
                "(in ${delay / 1000}s)"

        val wakeDelay = (delay - LEAD_MS).coerceAtLeast(0)
        wakeRunnable = Runnable { armSpinWait(targetMillis, x, y) }
        mainHandler.postDelayed(wakeRunnable!!, wakeDelay)
    }

    /** Runs on a dedicated thread so the busy-wait doesn't block the UI thread. */
    private fun armSpinWait(targetMillis: Long, x: Float, y: Float) {
        spinThread = Thread {
            while (System.currentTimeMillis() < targetMillis) {
                // Tight spin for the final stretch. This trades battery/CPU
                // for timing precision; it only runs for LEAD_MS at most.
            }
            val service = TapAccessibilityService.instance
            mainHandler.post {
                if (service == null) {
                    textStatus.text = "Status: FAILED - accessibility service not connected"
                } else {
                    service.tapAt(x, y)
                    textStatus.text = "Status: tapped at ${System.currentTimeMillis()}"
                }
            }
        }
        spinThread!!.start()
    }

    private fun cancelScheduled() {
        wakeRunnable?.let { mainHandler.removeCallbacks(it) }
        wakeRunnable = null
        spinThread?.interrupt()
        spinThread = null
        textStatus.text = "Status: idle"
    }

    override fun onDestroy() {
        super.onDestroy()
        cancelScheduled()
    }
}
