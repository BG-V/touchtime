package com.example.touchattime

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Full-screen view: tap anywhere and its pixel coordinates are returned
 * to MainActivity via setResult.
 */
class PickPointActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val label = TextView(this).apply {
            text = "Tap anywhere to set the target point"
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(32, 32, 32, 32)
        }

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.DKGRAY)
            addView(label)
        }

        root.setOnTouchListener { _: View, event: MotionEvent ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val result = Intent().apply {
                    putExtra("x", event.rawX.toInt())
                    putExtra("y", event.rawY.toInt())
                }
                setResult(RESULT_OK, result)
                finish()
            }
            true
        }

        setContentView(root)
    }
}
